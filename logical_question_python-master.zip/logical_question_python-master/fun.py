#def add(num,num1):
#	add1=num+num1
#	print add1
#add(6,7)

#def welcome():
#	print "python kaisa lagta h aapko"
#	print "but please reply na kare aap"
#welcome()


user = int(raw_input("enter a number"))
i = 0
new = []
while i < (user):
	user1 = int(raw_input("enter a number"))
	new.append(user1)
	i = i + 1
print new
print "**********************************************"

i = 0
new_list = []
while i < len(new):
	if new[i]%2 == 0:
		new_list.append(new)
	else:
		new_list.append(new)
	i = i + 1
print new_list
	

	




