user = int(raw_input("enter your number"))
if user < 0:
	user = user * (-1)
	print user
else:
	if user > 0:
		print (-user)
