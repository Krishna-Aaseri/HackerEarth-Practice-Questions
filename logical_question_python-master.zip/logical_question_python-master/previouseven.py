num = int(raw_input("enter a number"))
i=1
var = num
while i <= 3:
	var=var-1
	if var%2==0:
		print "even h",var
		i = i + 1
a=1
while a <= 3:
	num=num+1
	if num%2!=0:
		print "odd h",num
		a = a + 1

#user = int(raw_input("enter a number"))
#i=1
#while i <= 3:
#	user=user-1
#	if user%2==0:
#		print "even h",user
#	i = i + 1
