i = 0
while i <= 10:
	if i == 4:
		print i 
	elif i == 5:
		print i
	i = i + 1