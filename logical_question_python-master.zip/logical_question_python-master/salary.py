user = int(raw_input("enter a number"))
i = 2
while i <= user:
	if user % 2 != 0:
		print i,"prime hain"
	else:
		print i,"prime nhi h"
	i = i + 1

