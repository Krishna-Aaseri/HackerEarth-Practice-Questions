#output = user will give 12 after that isme se add krke 12 krke dena hain

# string = [10,12,12,13,14,2]
# i = 0
# new = []
# user = int(raw_input("enter your number"))
# while i < len(string):
# 	j = 0
# 	while j < len(string):
# 		if string[i]+string[j] == user:
# 			new.append(string[i])
# 		j = j + 1
# 	i = i + 1
# print new
                                 

# var = ['a','b','c','d','e']
# var2 = [1,2,3,4,5]
# #output should be  {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
# i = 0
# new = []
# while i < len(var):
# 	new.append((var[i],val2[i])
# 	i = i + 1
# print new

# places = ["delhi", "gujrat", "rajasthan", "punjab", "kerala"]
# i = len(places)
# while i > 1:
# 	i = i - 1
# 	print places[i]

# n = [10, 11, 12, 13, 14, 17, 18, 19]
# i = 0
# new = []
# number = 30
# while i < len(n):
# 	j = 0
# 	while j < len(n):
# 		if n[i] + n[j] == number:
# 			new.append([n[i],n[j]])
# 		j = j + 1
# 	i = i + 1
# print new

# num = [[8, 3, 4],[1, 5, 9],[6, 7, 2]]
# sum1 = 0
# i = 0
# while i<len(num):
# 	j = 0
# 	while j<len(num):
# 		sum1 = sum1 + num[i]
# 	j = j + 1
# i = i + 1
# print sum1

# kajal = {"name":"kaju","id":2,"class":"bsc"}
# #print kajal.get("name")
# for i in range(0,3):
# 	print kajal.value


# released = {
# 		"iphone" : 2007,
# 		"iphone 3G" : 2008
# 	}
# print released

# k = {"phone":34353535,"python":"aacha h"}
# print k["phone"]


# #output = [6][15][24]
# num = [[1,2,3],[4,5,6],[7,8,9]]
# i = 0
# new = []
# sum1 = 0
# while i<len(num):
# 	num1 = num[i]
# 	j = 0
# 	while j<len(num1):
# 		sum1 = sum1 + num1[j]
# 		j = j + 1
# 	new.append(sum1)
# 	i = i + 1
# print new








