user = input("enter your number")
i = 1
while i <= 5:
	print (-user)
	user = user - 1
	if user == 5:
		break
	i = i + 1


	 

	
