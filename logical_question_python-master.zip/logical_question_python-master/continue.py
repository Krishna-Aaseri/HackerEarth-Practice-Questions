i = 1
while i < 10:
	if i == 1:
		i = i + 1 
		continue
		print i 
	i = i + 1
	print i


a = [2,3,5,7,5,7]
i = 0
sum = 0
while i < len(a):
    sum = sum + a[i] 
    i = i + 1
print sum