# level 2 in 
# 1) qus



sum = 0
i = 1
while i <= 3:
	user = int(raw_input("enter your number"))
	sum = sum + user
	i = i + 1
print sum


sum = 0
i = 1
while i <= 5:
	user = int(raw_input("enter your number"))
	sum = sum + user
	i = i + 1
print sum

# qus 3 and level 2


num = "kajal"
i = 1
var = -1
while i <= len(num):
	print (num[var]),
	var = var -1
	i = i + 1
