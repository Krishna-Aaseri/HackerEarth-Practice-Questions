#20 se bada 40 se chota number

# num = [50, 40, 23, 21,70, 56, 10, 7]
# i = 0
# count = 0
# while i < len(num):
# 	if num[i] > 20 and num[i] < 40:
# 		count = count + 1
# 	i = i + 1
# print count


# def add(list1):
# 	list1 = [19,17,12,17,17,18,10,17,14,12,19,17,12,13,11]
# 	#output = [19,17,12,18,10,14,13,11]
# 	i = 0
# 	new = []
# 	while i < len(list1):
# 		if list1[i] not in new:
# 			new.append(list1[i]) 
# 		i = i + 1
# 	print new
# add([19,17,12,17,17,18,10,17,14,12,19,17,12,13,11])

kajal = {"name":"kaju","id":2,"class":"bsc"}
print kajal("name")

