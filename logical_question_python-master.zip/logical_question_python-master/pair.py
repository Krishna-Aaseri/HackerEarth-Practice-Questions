
# string = [[1,2,3],[4,5,6],[7,8,9]]
# i = 0
# sum = 0
# while i < len(string):
# 		sum = sum + string[i][i]
# 		i = i + 1
# print sum

# var1 = [3,5,78,2,4]
# user = input("enter a number")
# i = 0
# while i < len(var1):
# 	if user == var1[i]:
# 		print user,i
# 	i = i + 1

# i = 1
# sum1 = 0
# while i < 1000:
# 	if i%3 == 0 and i%5 == 0:
# 		sum1 = sum1 + i
# 	i = i + 1
# print sum1

# i = 0
# while i < 10:
# 	if i == 5:
# 		continue
# 	i = i + 1


# var = "python"
# i = 0
# while i < var:
# 	if var[i] == "n":
# 		print var[i],i
# 		continue
# 	i = i + 1

# i = 0
# while i < 5:
# 	if i == 5: 
# 		continue
# 	i = i + 1
# print i


                                                                                                                                                                                                           Today challening question
