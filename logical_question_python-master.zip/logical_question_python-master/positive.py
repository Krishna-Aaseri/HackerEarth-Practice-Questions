user = int(raw_input("enter your number"))
if user > 0:
	print "positive umber h",user
else:
	print "nagative h",user