# maxium number

num = [50, 40, 23, 70, 100, 7]
var = 0
i = 0
while i < len(num):
	if var < num[i]:
	   var = num[i]
	i = i + 1
print var

# minium number

num = [50, 40, 23, 70, 100, 7]
var = 0
i = var
while i < len(num):
	if var < num[i]:
	   var = num[i]
	i = i + 1
print var
