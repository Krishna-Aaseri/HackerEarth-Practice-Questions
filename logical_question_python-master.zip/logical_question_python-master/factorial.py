num = int(raw_input("enter your number"))
i = 1
while num >= 1:
	i = num * i
	num = num - 1
print i 

# user = raw_input("enter yourt number")
# if user == "monday" or "tuesday" or "wednesday" or "tuesday" or "frieday":
# 	print "working day"
# elif user == "saturday" or "sunday":
# 	print "holiday"
# else:
# 	print "nothing"