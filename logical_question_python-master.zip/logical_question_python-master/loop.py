# i = 0
# while i <= 1:
# 	i = i + 1
# 	print i


# i = 1
# while i <= 1: 
# 	i = i + 1
# 	print i 

# i = 0
# while i <= 5:
# 	i = i + 1
# print i
