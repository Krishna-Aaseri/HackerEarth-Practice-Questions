a = input("enter your number")
b = input("enter your number")
c = input("enter your number")
if a>b:
 	if a<c:
 		print a
 	elif b>a:
 		print b
 	else:
 		print c
else:
	if a>c:
		print a
	elif b<c:
		print c
 	else:
		print c

