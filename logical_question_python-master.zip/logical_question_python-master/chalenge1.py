#i = 1
#while i <= 4:
#	print "*" * i
#	i = i + 1



#i = 7
#while i >= 1:
#	print "0" * i
#	print ""
#	i = i - 2



i = 7
a = 0
while i >= 1:
	print "10" * i
	i = i - 2	



