i = 1
while i <= 240:
	if i % 24 == 0:
		print i
	i = i + 1
