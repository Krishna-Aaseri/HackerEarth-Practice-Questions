# user =  int(raw_input("enter your number"))
# i = 2
# while i < user:
# 	if  user % 2 == 0:
# 		print "prime  nhi h",user
# 		break
# 	i = i + 1 
# else:
# 		print "prime  h",user

user =  int(raw_input("enter your number"))
i = 2
while i < user:
	if  user % 2 == 0:
		print 0
		break
	i = i + 1 
else:
		print user