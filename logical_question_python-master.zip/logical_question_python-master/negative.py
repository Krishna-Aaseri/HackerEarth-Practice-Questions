i = 1
while i <= 50:
	if i > 0:
		print "positive h",i 
		i = i + 1