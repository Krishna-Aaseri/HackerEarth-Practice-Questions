i = 0
num = 1
while i < 3:
	j = 0
	while j < 6:
		if num == 2:
			num = 0
		print num,
		j = j + 1
		num = num + 1
	print " "
	i = i + 1

		