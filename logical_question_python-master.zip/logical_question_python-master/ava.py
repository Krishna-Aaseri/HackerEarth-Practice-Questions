i = 1
sum = 0
while i <= (10):
	user = int(raw_input("enter your nu7mber"))
	sum = sum + user
	ava = sum / i
	i = i + 1
print ava
